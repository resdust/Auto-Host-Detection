# electron-web-report
Run on a web server machine to receive vulnerability validation data and to generate report.
You need a node environment to run this code.

## To Use

```bash
# Install dependencies
npm install
# Run the app
npm start
```